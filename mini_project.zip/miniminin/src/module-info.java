module miniminin {
	requires java.se;
}