package com.kim.util;

public class Utility {

	public Utility() {
	}

}
