package com.kim.view;

import java.util.ArrayList;

import com.kim.dto.DepositClass;

public class PrintResult {

	public PrintResult() {
	}
	
	public static void printSelectAll(ArrayList<DepositClass>Depositlist) {
		for(DepositClass Deposit : Depositlist) {
			System.out.println(Deposit);
		}
	}
	
	public static void printMenu() {
		System.out.println("원하는 번호를 입력해주세요.");
		System.out.println("1.전체조회 2.은행선별 3. 4. 5.작업 종료");
		
	}
}

