package com.kim.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.kim.dto.DepositClass;

public class MySQLConnector implements Querys{

	private String driver = "com.mysql.cj.jdbc.Driver";
	private String url = "jdbc:mysql://localhost:3306/db_bank?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
	private String id_mysql = "root";
	private String pw_mysql = "1234";

	public Connection conn = null;

	
	
	public MySQLConnector() {
	}

	
	
	public void connectMySQL() {
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, id_mysql, pw_mysql);
			System.out.println("MySQL 접속성공(._ .");

		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFound ERR : " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("getConnection ERR : " + e.getMessage());
		}
	}

	
	
	
	public static ArrayList<DepositClass> Depositlist = null;

	
	
	
	public void selectAll() {
		Statement stmt = null;
		ResultSet rs = null;
		

		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(querySelectAll);
			
			Depositlist = new ArrayList<DepositClass>();
			
			
			
			while (rs.next()) {
				int SeqNo = rs.getInt("SeqNo");
				String BankName = rs.getString("BankName");
				String DepositName = rs.getString("DepositName");
				float TaxDiscount = rs.getFloat("TaxDiscount");
				float Discount = rs.getFloat("Discount");
				String JoinLimit = rs.getString("JoinLimit");
				String DepositType = rs.getString("DepositType");
				int Month = rs.getInt("Month");

				Depositlist.add(new DepositClass(SeqNo, BankName, DepositName, TaxDiscount, Discount, JoinLimit,
						DepositType, Month));	
			}

		} catch (SQLException e) {
			System.out.println("SelectAll() ERR : " + e.getMessage());
		} finally {
			close(stmt, rs);
		}
		System.out.println("전체 레코드 조회 성공");
		
	}
	
	public void selectBank(String BankName) {
		PreparedStatement pstmt =null;
		ResultSet rs = null;
		
		try {
			//"select*from deposit where BankName=?";
			pstmt = conn.prepareStatement(queryBank);
			pstmt.setString(1, BankName);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				System.out.println(rs.getInt("SeqNo") + "\t" + rs.getString("BankName"));
			}
			
			
		
		} catch (SQLException e) {
			System.out.println("selectBank ERR : " + e.getMessage());
		}finally {
			close(pstmt, rs);
		}
	}
	
	
	
	public void close(Statement stmt, ResultSet rs) {
		try {
			stmt.close();
			rs.close();
		}catch(SQLException e) {
			System.out.println("Statement stmt, ResultSet rs : " + e.getMessage());
		}
	}
	
	public void close1() {
		try {
			conn.close();
		}catch(SQLException e) {
			System.out.println("connection ERR : " + e.getMessage());
		}
	}
	
	public void close(PreparedStatement pstmt, ResultSet rs) {
		try {
			pstmt.close();
			rs.close();
		}catch(SQLException e) {
			System.out.println("PreparedStatement pstmt, ResultSet rs : " + e.getMessage());
		}
	}
	
	public void close(PreparedStatement pstmt) {
		try {
			pstmt.close();
		}catch(SQLException e) {
			System.out.println("PreparedStatement pstmt : " + e.getMessage());
		}
	}
}
