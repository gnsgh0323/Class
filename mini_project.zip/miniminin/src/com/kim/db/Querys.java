package com.kim.db;

public interface Querys {
	String querySelectAll = "select * from deposit";
	String queryBank = "select*from deposit where BankName=?";
}
