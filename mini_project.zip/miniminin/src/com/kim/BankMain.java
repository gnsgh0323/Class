package com.kim;

import java.util.Scanner;

import com.kim.db.MySQLConnector;
import com.kim.view.PrintResult;



public class BankMain {

	public static void main(String[] args) {
		MySQLConnector mysql = new MySQLConnector();
		mysql.connectMySQL();

		PrintResult.printMenu();

		Scanner scan = new Scanner(System.in);

		boolean status = true;
		while (status) {

			int n = scan.nextInt();

			if (n == 1) {
				mysql.selectAll();
				PrintResult.printSelectAll(mysql.Depositlist);
				PrintResult.printMenu();

			} else if (n == 2) {
				System.out.println("은행 이름을 입력해주세요.");
				String sb = scan.next();
				mysql.selectBank(sb);
				
				PrintResult.printMenu();

			} else if (n == 3) {

			} else if (n == 4) {

			} else if (n == 5) {

				System.out.println("작업 종료");

			}

		}
		scan.close();
	}
	

}
