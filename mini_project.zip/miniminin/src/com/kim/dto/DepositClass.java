package com.kim.dto;

public class DepositClass {
	private int SeqNo = 0;
	private String BankName = "";
	private String DepositName = "";
	private float TaxDiscount = 0;
	private float Discount = 0;
	private String JoinLimit = "";
	private String DepositType = "";
	private int Month = 0;

	public DepositClass() {
	}

	public DepositClass(int seqNo, String bankName, String depositName, float taxDiscount, float discount,
			String joinLimit, String depositType, int month) {
		this.SeqNo = seqNo;
		this.BankName = bankName;
		this.DepositName = depositName;
		this.TaxDiscount = taxDiscount;
		this.Discount = discount;
		this.JoinLimit = joinLimit;
		this.DepositType = depositType;
		this.Month = month;
	}

	public int getSeqNo() {
		return SeqNo;
	}

	public void setSeqNo(int seqNo) {
		SeqNo = seqNo;
	}

	public String getBankName() {
		return BankName;
	}

	public void setBankName(String bankName) {
		BankName = bankName;
	}

	public String getDepositName() {
		return DepositName;
	}

	public void setDepositName(String depositName) {
		DepositName = depositName;
	}

	public float getTaxDiscount() {
		return TaxDiscount;
	}

	public void setTaxDiscount(float taxDiscount) {
		TaxDiscount = taxDiscount;
	}

	public float getDiscount() {
		return Discount;
	}

	public void setDiscount(float discount) {
		Discount = discount;
	}

	public String getJoinLimit() {
		return JoinLimit;
	}

	public void setJoinLimit(String joinLimit) {
		JoinLimit = joinLimit;
	}

	public String getDepositType() {
		return DepositType;
	}

	public void setDepositType(String depositType) {
		DepositType = depositType;
	}

	public int getMonth() {
		return Month;
	}

	public void setMonth(int month) {
		Month = month;
	}

	@Override
	public String toString() {
		return "DepositeClass [SeqNo=" + SeqNo + ", BankName=" + BankName + ", DepositName=" + DepositName
				+ ", TaxDiscount=" + TaxDiscount + ", Discount=" + Discount + ", JoinLimit=" + JoinLimit
				+ ", DepositType=" + DepositType + ", Month=" + Month + "]";
	}

	
}
