module day10_bootcamp {
	requires java.se;
}