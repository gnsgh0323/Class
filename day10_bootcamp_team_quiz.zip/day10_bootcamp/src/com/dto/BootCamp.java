package com.dto;

public class BootCamp {
	private int cSeqNo = 0;
	private String cName = "";
	private String cRating = "";
	private String cJoinDate = "";
	private String cLastDate = "";
	private int cVisitNo = 0;
	private int cPotstNo = 0;
	private int cCommentNo = 0;
	private String cGenger = "";
	private String cAge = "";
	
	public BootCamp() {
	}
	
	public BootCamp(int cSeqNo, String cName, String cRating, String cJoinDate,String cLastDate, int cVisitNo, int cPostNo, int cCommentNo, String cGenger, String cAge) {
		this.cSeqNo = cSeqNo;
		this.cName = cName;
		this.cRating = cRating;
		this.cJoinDate = cJoinDate;
		this.cLastDate = cLastDate;
		this.cVisitNo = cVisitNo;
		this.cPotstNo = cPostNo;
		this.cGenger = cGenger;
		this.cAge = cAge;
	}

	public int getcSeqNo() {
		return cSeqNo;
	}

	public void setcSeqNo(int cSeqNo) {
		this.cSeqNo = cSeqNo;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public String getcRating() {
		return cRating;
	}

	public void setcRating(String cRating) {
		this.cRating = cRating;
	}

	public String getcJoinDate() {
		return cJoinDate;
	}

	public void setcJoinDate(String cJoinDate) {
		this.cJoinDate = cJoinDate;
	}

	public String getcLastDate() {
		return cLastDate;
	}

	public void setcLastDate(String cLastDate) {
		this.cLastDate = cLastDate;
	}

	public int getcVisitNo() {
		return cVisitNo;
	}

	public void setcVisitNo(int cVisitNo) {
		this.cVisitNo = cVisitNo;
	}

	public int getcPotstNo() {
		return cPotstNo;
	}

	public void setcPotstNo(int cPotstNo) {
		this.cPotstNo = cPotstNo;
	}

	public int getcCommentNo() {
		return cCommentNo;
	}

	public void setcCommentNo(int cCommentNo) {
		this.cCommentNo = cCommentNo;
	}

	public String getcGenger() {
		return cGenger;
	}

	public void setcGenger(String cGenger) {
		this.cGenger = cGenger;
	}

	public String getcAge() {
		return cAge;
	}

	public void setcAge(String cAge) {
		this.cAge = cAge;
	}

	@Override
	public String toString() {
		return "BootCamp [cSeqNo=" + cSeqNo + ", cName=" + cName + ", cRating=" + cRating + ", cJoinDate=" + cJoinDate
				+ ", cLastDate=" + cLastDate + ", cVisitNo=" + cVisitNo + ", cPotstNo=" + cPotstNo + ", cCommentNo="
				+ cCommentNo + ", cGenger=" + cGenger + ", cAge=" + cAge + "]";
	}
	
}
