package com.main;

public interface Querys {
	String querySelectAll = "select * from bootcamp2";
	String querySelectOne = "select * from bootcamp2 where cAge=?";
	String queryInsert = "insert into bootcamp2(cName, cRating, cJoinDate, cLastDate, cVisitNo, cPostNo, cCommentNo,\r\n"
			+ "						cGenger, cAge)values(?,?,?,?,?,0,0,?,?)";
	String queryUpdate = "update bootcamp2 set cGenger=? where cGenger=?";
	
	String queryDelete = "delete from employee where job=?";
}
