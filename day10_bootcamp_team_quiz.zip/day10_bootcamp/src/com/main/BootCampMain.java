package com.main;

import java.util.ArrayList;
import java.util.Scanner;

import com.db.MySQLconnector;
import com.dto.BootCamp;

public class BootCampMain {

	public static void main(String[] args) {
		MySQLconnector mysql = new MySQLconnector();
		mysql.connectMySQL();
		ArrayList<BootCamp> bclist = null;

		PrintResult.printMenu();

		Scanner scan = new Scanner(System.in);

		boolean status = true;
		while (status) {

			int n = scan.nextInt();

			if (n == 1) {

				bclist = mysql.selectAll();
				PrintResult.printSelectAll(bclist);

				PrintResult.printMenu();

			} else if (n == 2) {

				mysql.update(bclist);
				PrintResult.printMenu();

			} else if (n == 3) {

				mysql.insert();
				bclist = mysql.selectAll();
				PrintResult.printMenu();

			} else if (n == 4) {
				
				bclist = mysql.selectAll();
				mysql.selectVisit(bclist);
				
				PrintResult.printMenu();

			} else if (n == 5) {
				
				mysql.selectOne();
				bclist = mysql.selectAll();
				PrintResult.printMenu();
				
			} else if (n == 6) {

				System.out.println("�۾� ����");
			}

		}
	}

}
