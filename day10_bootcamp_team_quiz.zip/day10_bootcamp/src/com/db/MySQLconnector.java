package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.dto.BootCamp;
import com.main.Querys;


public class MySQLconnector implements Querys {

	private String driver = "com.mysql.cj.jdbc.Driver";
	private String url = "jdbc:mysql://localhost:3306/db_bootcamp?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
	private String id_mysql = "root";
	private String pw_mysql = "1234";

	public Connection conn = null;

	public MySQLconnector() {
	}

	public void connectMySQL() {

		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, id_mysql, pw_mysql);
			System.out.println(" MySQL ���� ���� !!!");

		} catch (ClassNotFoundException e) {
			System.out.println("Class.forName(driver) ERR : " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("getConnection() ERR : " + e.getMessage());
		}
	}

	// ������ ��ü ��ȸ
	public ArrayList<BootCamp> selectAll() {
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<BootCamp> bclist = null;

		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(querySelectAll);

			bclist = new ArrayList<BootCamp>();

			while (rs.next()) {
				int cSeqNo = rs.getInt("cSeqNo");
				String cName = rs.getString("cName");
				String cRating = rs.getString("cRating");
				String cJoinDate = rs.getString("cJoinDate");
				String cLastDate = rs.getString("cLastDate");
				int cVisitNo = rs.getInt("cVisitNo");
				int cPostNo = rs.getInt("cPostNo");
				int cCommentNo = rs.getInt("cCommentNo");
				String cGenger = rs.getString("cGenger");
				String cAge = rs.getString("cAge");

				bclist.add(new BootCamp(cSeqNo, cName, cRating, cJoinDate, cLastDate, cVisitNo, cPostNo, cCommentNo,
						cGenger, cAge));
			}

		} catch (SQLException e) {
			System.out.println("selectAll() ERR : " + e.getMessage());
		} finally {
			try {
				rs.close();
				stmt.close();
			} catch (SQLException e) {
				System.out.println("Close ERR : " + e.getMessage());
			}
		}

		System.out.println("��ü ��ȸ ����");
		return bclist;
	}
	

	// ���� ������� ����� �湮Ƚ��
	public void selectOne() {
		
		String age = "�����";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement("select * from bootcamp2 where cAge=?");
			pstmt.setString(1, age);
			rs = pstmt.executeQuery();
					
			while(rs.next()) {
				System.out.println(rs.getInt("cVisitNo") + "\t" + rs.getString("cName"));
				}
					
				}catch (SQLException e) {
					System.out.println("selectOne() ERR : " + e.getMessage());
					
				}finally {
					try {
						rs.close();
						pstmt.close();				
					}catch (SQLException e) {
						System.out.println("CLOSE ERR : " + e.getMessage());
					}
				}
				
			}
	
	// ������ ���� : ��� �߰�
	public void insert() {
		
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(queryInsert);
			
			 pstmt.setString(1, "��߿�");
			 pstmt.setString(2, "���");
			 pstmt.setString(3, "2023-06-22");
			 pstmt.setString(4, "2023-07-05");
			 pstmt.setInt(5, 45);			 
			 pstmt.setString(6, "��");
			 pstmt.setString(7, "20�� �ʹ�");
		
			 int n = pstmt.executeUpdate();
			 if(n>0) {
				 System.out.println(n + "���� ���ڵ� ���� ����");
			 }
		}catch(SQLException e) {
			System.out.println("insert() ERR : " + e.getMessage());
		}finally {
			try {
				pstmt.close();
			}catch(SQLException e) {
				System.out.println("Close ERR : " + e.getMessage());
			}
		}
		

		System.out.println("���� ����");
	}
	
	//������ ���� : ������ ��Ÿ�� ��� ���� ����
		public void update(ArrayList<BootCamp> bclist) {
			String update = "X";
			String b = "��Ÿ";
			PreparedStatement pstmt = null;
			int n = 0;
			try {
				pstmt = conn.prepareStatement(queryUpdate);
				pstmt.setString(1, update);
				pstmt.setString(2, b);
				n = pstmt.executeUpdate();
				if (n > 0) {
					System.out.println(n + "�� ���� �Ϸ�");
				}
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
			System.out.println("������ ���� ����!");
			// update() END
		}

		// ��� �湮Ƚ�� ���� ���� �湮�� ���
		public void selectVisit(ArrayList<BootCamp> bclist) {
			int sum = 0;
			for(int i = 0; i < bclist.size(); i++) {
				sum = sum + bclist.get(i).getcVisitNo();
			}
			
			int avg = sum/bclist.size();
			for(int k = 0; k < bclist.size(); k++) {
				if(bclist.get(k).getcVisitNo() > avg) {
					System.out.println(bclist.get(k).getcName());
					
				}
			}
		}

		
}
	