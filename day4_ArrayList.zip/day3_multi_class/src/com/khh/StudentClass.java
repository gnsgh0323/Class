package com.khh;

public class StudentClass {
	// ("1292001", "900424-1825409", "�豤��", 3, "����', 92);
			String sNo = null;
			String firstNo = null;
			String lastNo = null;
			String name = null;
			int year = 1;
			String local = null;
			int grade = 0;
			String jumin = null;
			
	public StudentClass() {
			
	}
	
    public StudentClass(String sNo, String jumin, String name, int year, String local, int grade) {
    	  	this.sNo = sNo;
    	  	String[] temp = jumin.split("-");
    	  	this.firstNo = temp[0];
    	  	this.lastNo = temp[0];
    	  	this.name = name;
    	  	this.year = year;
    	  	this.local = local;
    	  	this.grade = grade;
    	  	this.jumin = jumin;
    }
}
