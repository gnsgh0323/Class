package com.khh;

import java.util.ArrayList;

public class NewsPrintClass {
	public NewsPrintClass() { // �⺻ ������
		
	}
//  1)public static void printURL(String press, String url) {
	 public static void printURL(String press, ArrayList<String> url) {
		for(int idx = 0; idx< url.size(); idx++) {
			
//			System.out.println(press + "�� ��ũ�ּ� : https://" + url);
			System.out.println(press + "�� ��ũ�ּ� : https://" + url.get(idx));
		}
	}
	 public static void printCategory(String press, ArrayList<String>category) {
		  for(int idx = 0; idx < category.size(); idx++) {
			  System.out.println(category.get(idx));
		  }
	 }
}
