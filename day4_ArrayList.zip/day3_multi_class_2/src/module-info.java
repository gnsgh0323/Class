module day3_multi_class_2 {
}