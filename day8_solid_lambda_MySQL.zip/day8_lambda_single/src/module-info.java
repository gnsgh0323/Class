module day8_lambda {
}