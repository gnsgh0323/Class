package day8_lambda;


/** SingleTon : 자바 디자인 패턴 중, 대표적인 패턴
 
 	하나의 어플리케이션에 단 하나의 객체만 존재하도록 설계하는 패턴
 	1. 객체 저장 변수는 static을 이요하여 공유 객체로 선언
 	2. 생성자는 반드시 private으로 선언하여 외부에서 객체 생성하지 못하도록 해야한다.
 	3. public method를 이용하여 생성된 객체를 반환 받는다!!
 	
 	예) Workbook.createWritable() 처럼
 	
 	주로 데이터 베이스에 접근할 때 사용
**/
public class SingleTonClass {
	public static SingleTonClass single = null;
	
	private SingleTonClass() {
	}  // --> private이라 접근이 불가능하여 객체 생성이 불가능하니 
	   //     static을 붙여 접근할 수 있게 한다.
/* (1) 두가지 방법	
	public static SingleTonClass getIntance() {
		single = new SingleTonClass();
		return single;
	}
*/
/* (2) */	
	public static void getInstance() {
		single = new SingleTonClass();
	}
}
