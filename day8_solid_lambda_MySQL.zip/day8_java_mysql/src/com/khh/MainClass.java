package com.khh;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MainClass {

	public static void main(String[] args) {
		// 1. MySQL 접속 드라이버 로드
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("드라이버 로드 성공");
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException" + e.getMessage());
		}     
		
		/*
		 	2. MySQL 서버 접속 : 서버 주소 / 관리자 id / password / database명
			  DriverManager.getConnection(null);
		 	  서버접속 프로토콜 : jdbc:mysql://
		 	  서버 주소 : localhost
		 	  데이터 통신 게이트(포트번호) : 3306
		 	  사용할 DB 명 : test
		 	  서버주소 : "jdbc:mysql://localhost:3306/test"
		 	  서버 관리자 아이디 : "root"(고정되어있음)          -> 3개 다 문자열
			  서버 관리자 비밀번호 : 설치했을때 설정한 "비밀번호"
		 	  접속 결과를 저장하는 변수가 필요 : Connection 변수명
		 */
		
		Connection con = null;
		String url = "jdbc:mysql://localhost:3306/";
		String id = "root";
		String pw = "gnsgh0323";
		String dbName = "test";   // -> 이렇게 쓰면 url + "test"에서 test를 뺴도됨
		url = url + dbName;
		try {
			con = DriverManager.getConnection(url, id, pw);
			System.out.println("데이터베이스 접속 성공");
		} catch (SQLException e) {
			System.out.println("SQLException : " + e.getMessage());
		}
		
		/*
		   	3. MySQL에 요청 : SQL : SQLException
		      1. Statement  ->  쿼리문 내에 변수가 포함되지 않을 경우
			  2. PreparedStatement  ->  쿼리문 내에 변수가 포함 될 경우
		 */
		
		/*
		    4. 결과 처리 : select * from 테이블명 : SQLException
		    	ResultSet 객체로 결과 전달 받는다.
		    	while(ResultSet.Next(){
		    		레코드(한줄) 하나씩 꺼내서
		    	}
		 */
		
		 /*
		   	5. 자원 해제
		   	  1. ResultSet.close();
		   	  2. Statement.close(); / Preparedstatement.close();
		   	  3. Connection.close();
		  */
		 
	}	
}	
	// Driver.class -> com.mysql.jdbc.Driver  :  접속 드라이버 명