module day8_solid {
}