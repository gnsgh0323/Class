package com.khh.dip;

public class Client {

	public Client() {
	}

}
