package com.khh.srp;

public class Programmer extends Person{

	public Programmer() {
	}

}
