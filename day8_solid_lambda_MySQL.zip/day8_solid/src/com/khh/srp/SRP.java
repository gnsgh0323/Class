package com.khh.srp;

// SRP가 지켜진 경우

public class SRP {		// SRP.java 의 대표 클래스
	public SRP() {
	}	
	//클래스 내부에 클래스 선언 가능 : 접근제한자 사용가능
	public class InnerClass{
	}
	public void method() {
		class InnerMethod{   // 메서드 내부에 클래스 선언 가능
			
		}
	} 
}

// 서브 클래스는 접근 제한자를 사용하지 못한다.
//public abstract class person2() {}   // 사용하면 오류남

abstract class Person2 {   // 메서드에는 접근제한자를 붙여도 상관이없다.
	public abstract void work();
} 
/*    // SRP 패키지의 SRP 파일 내부~!!
class Programmer extends Person2{
	@Override
	public void work() {
		System.out.println("코딩~~~");
	}
}

class PM extends Person2{
	public void work() {
		System.out.println("기획~~");
	}
}
*/