package com.khh.srp;

//SRP가 지켜지지 않은 경우

public class Person {
	public String job;

	public Person() { // 기본 생성자 -> 생략 가능하지만, 반드시 명시적으로 코딩할것!!
						            // 기본 생성자가 없을 경우, 컴파일시. 기본 생성자는 자동으로 만들어진다.
									// 다만, Java Web 또는 Spring Framework에서는
									// xml 문서를 통해 객체 생서이 이루어지기 때문에 반드시 명시해야한다!!
	}

	public Person(String job) { // Overloading 생성자
		this.job = job;
	}

	public void work() {		// 추상클래스 내부에 추상메서드로 만들던지  추상클래스 내부에 인터페이스로 만들어야한다.
		if (this.job.equals("Programmer")) {
			System.out.println("코딩하는 사람");
		} else if (this.job.equals("PM")) { // else if 한번 더 비교하는것
			System.out.println("기획하는 사람");
		}  // 이렇게 만들바엔 person을 상속받는 programmer, PM을 만드는게 낫다
	}
}
