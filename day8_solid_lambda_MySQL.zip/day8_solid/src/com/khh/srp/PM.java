package com.khh.srp;

public class PM extends Person {

	public PM() {
	}

}
