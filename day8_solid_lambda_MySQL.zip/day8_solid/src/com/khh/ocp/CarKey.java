package com.khh.ocp;

//OCP가 지켜지지 않은 경우

public class CarKey {  // 대표 클래스    // 스마트폰 키
	CarKey myCar;
	
	public CarKey() {
		
	}
	
	public CarKey(CarKey car) {
		this.myCar = car;
	}
	
	public void open() {
		System.out.println("문열림");
	}
	
	public void turnOn() {
		System.out.println("시동 걸림");
	}
	
	public void turnOff() {
		System.out.println("시동끔");
	}
	
	public void lock() {
		System.out.println("문닫힘");
	}
	
}

	class CarKeyA {  //서브 클래스
		public CarKeyA() {
			
		}
	}


