package com.khh.lsp;


import com.khh.srp.PM;
import com.khh.srp.Person;
import com.khh.srp.Programmer;

// LSP 적용 ( Person / Programmer / PM )
public class Main {

	public static void main(String[] args) {
			Person p1 = new Programmer();  // extends Person
			//Programmer p1 = new Programmer();
			Person p2 = new PM();						// extends Person
			// 부모 타입으로 형변환, 치환된 것.  -> Up Casting 됐다.    (치환 법칙)
			
			p1.work();    // 부모 클래스 타입으로 저장 받아도 자식클래스는 work() 메서드 사용가능
			p2.work();    // 부모 클래스 타입으로 저장 받아도 자식클래스는 work() 메서드 사용가능
			
			Object p3 = new PM();
			//p3.work();  // 사용불가
			// 사용 가능하게 하려면
			// 1. 부모 클래스 타입으로 형변환
			Person p4 = (Person)p3;   // Down Casting
			p4.work();
			// 2 .본인 클래스 타입으로 형변환
			PM p5 = (PM)p3; // Down Casting
			p5.work();
	}

	// 설계 시 주의 사항
    //	부모 클래스는 자식 클래스를 멤버(필드) 변수를 알 수 없기 때문에
	// 자식 클래스의 멤버(필드) 변수는 선언하지 않는다!!
	
}
