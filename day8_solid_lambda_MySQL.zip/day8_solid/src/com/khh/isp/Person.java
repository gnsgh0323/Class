package com.khh.isp;



/**
    ISP 적용 
  	상위 클래스에서 공통 부분을 구현하고  // 공통적인 부분은 상위에 작성
  	하위 클래스가 따로 구현 할 수 밖에 없는 메서드만 구현하도록 설계
**/
public abstract class Person {
	public Person() { }    // 기본 생성자를 봉하고 있지만 new를 이용하여 단독 객체생성이 불가능하다.
						   // ==> 클래스 자체가 추상 클래스이기 때문에
						   //     추상 클래스의 생성자는 상속 부분에서만 사용된다!

	public abstract void work();   // 추상 메서드 : 메서드명 까지만 선언
	// public void Eating();
	// public void Sleeping();
	
	public void Eating() {
		System.out.println("~~먹다");
	}
	
	public void Sleeping() {
		System.out.println("~~자다");
	}   // 이런 형태로 쪼개서 하나하나 만들지말고
		// 추상메서드로 public abstract void work(); 이렇게 하나로 만들어서 사용하는게 
		// 편하고 좋다.
}
