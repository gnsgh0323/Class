package com.khh.isp;

/* ISP 미적용 : 공통 모듈 개발할 때 사용한다
	부모 클래스는 각 자식 클래스의 공통 부분 구현 받도록 설계   --> 이 개념을 확대한게 AOP(관점 지향 프로그래밍)
	자식 클래스는 자신만의 메서드를 구현할 수 있도록 설계
*/

public class Programmer extends Person{

	@Override
	public void work() {
	}

/**
	public void Eating() { // 내부에 재정의 메서드를 선언하는건 안좋다.
		
	}    
	
	public void Sleeping() {  // 재정의
		
	}
**/
	
	public void backDev() {
		System.out.println("백엔드 개발");
	}
}
