package day3_multi_class_2;

// ��ü ��Ʈ�� Ŭ����
public class MainClass {

	public static void main(String[] args) {
		 DataClass dc = new DataClass();
		 
		 double[] realPrice = MethodClass.realPriceMethod(dc.books);
		 PrintClass.prn(dc.books, realPrice);
		 
	}

}
