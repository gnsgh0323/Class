package day3_multi_class_2;
// å �ѱǿ� ���� ���� Ŭ����
public class BookClass {
	 //            title                         author           press             price          image             dc
	//("DO it HTML 5 CSS 3", "������", "�������ۺ�����", 16800, "06365234.jpg", 20);
			String title = null;
			String author = null;
			String press = null;
			int price = 0;
			String image = null;
			int dc = 0;
	
	
	public BookClass() {
		
	}
  
	public BookClass(String title, String author, String press, int price, String image, int dc) {
		this.title = title;
		this.author = author;
		this.press = press;
		this.price = price;
		this.image = image;
		this.dc = dc;
	}
}
