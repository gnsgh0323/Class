package com.khh;

public class interfaceTest2 implements A {
	int ddd = 0;

	public interfaceTest2() {
	}

	@Override
	public void sum() {
		System.out.println("B");
	}

}
