package com.khh;

public interface C extends A, B {

}
