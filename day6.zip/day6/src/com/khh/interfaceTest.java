package com.khh;

public class interfaceTest implements A, B {
	int ccc = 0;

	public interfaceTest() {
		// a = 100; // interface 에 선언된 변수는 final이 붙은 상수이다!
		int c = a; // 값을 변경시키는건 안되지만 상수이기 때문에 추출은 가능하다.
	}

	@Override // interface에 선언 된 메서드를 재정의 했다라는 어노테이션
	public void sum() {
		System.out.println("A");
	}

	// Spring Framework 에서는 위와 같은 어노테이션을
	// 이용하여 여러가지 기능을 구현할 수 있다.
}
