package com.khh.test;

import com.khh.ParentClass;

public class Child2 extends ParentClass {

	public Child2() {
		
	}

//	public Child2(int n) {
//		super(n);
		
//	}

}
