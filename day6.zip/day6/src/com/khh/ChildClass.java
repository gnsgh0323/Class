package com.khh;

// parentClass를 상속 받으려면 클래스 생성할때 superClass에서 브라우저 설정해준다
public class ChildClass extends ParentClass {

	public ChildClass() {
		//System.out.println();     super는 다른 코드 아래 사용불가 무조건 위에 있어야함
		super(1000);   // 부모클래스의 생성자에게 값을 전달
		System.out.println("ChildClass 생성자 종료");
	}

}
