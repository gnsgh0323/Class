package com.khh;

public class ParentClass {
	int a = 10;												// default
	protected String name = "khh";                         //protected 자식한테 까지는 허용함
	private boolean b = false;                 
	public char c = 'A';

	public ParentClass() {

	}

	public ParentClass(int n) {
		this.a = n;
		
		System.out.println("ParentClass() 생성자 종료");
	}

	// Object.class 의 toString() 를 재정의 : Override
	public String toString() { // Object가 물려준 메서드
		String result = a + "--" + name;
		return result;
	}
}
