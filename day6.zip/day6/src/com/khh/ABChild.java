package com.khh;

public class ABChild extends ABClass{

	public ABChild() {
		System.out.println("ABchild() 생성자 호출");
	}

	@Override
	public void prn() {
		// TODO Auto-generated method stub
		
	}
	
	
}
