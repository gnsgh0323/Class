package com.khh;

public interface B extends A{

}
