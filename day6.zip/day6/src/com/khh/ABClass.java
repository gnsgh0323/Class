package com.khh;
			
 
public abstract class ABClass {
	int a = 0;
	final boolean B = true; // 상수명은 전부 대문자 (규칙은 아니지만 개발자끼리의 약속)
	public ABClass() {
		System.out.println("ABClass() 호출 ");
	}

	public void avg() {

	}

	public abstract void prn();
}
