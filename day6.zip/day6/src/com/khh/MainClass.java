package com.khh;

public class MainClass {

	public static void main(String[] args) {
		// ChildClass c = new ChildClass(); // => parentClass에 대한 객체가 상속된다
		// A c = new interfaceTest2(); // interfaceTest c = new interfaceTest();
		 ABChild ab = new ABChild();  //-> 추상클래스의 생성자는 상속에서만 사용!!!
		 
	

	}

	
}
