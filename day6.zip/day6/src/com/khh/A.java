package com.khh;

public interface A {
	int a = 10;     // final이 붙은 상수로 선언됨.  따라서 더 이상 값을 변경할 수 없다.
	
	
//		public A() {   // interface는 생성자를 가질 수 없다. 만들면 오류발생
//		}							생성자를 가질 수 없다
	
//	public void sum() {  // interface 내에서는 메서드 선언이 불가능하다
//	}
	
	public void sum();   // interface 내에서는 메서드명만 선언이 가능하다
	// *이 interface 를 구현받는 클래스는 반드시 해당 메서드를 재정의 해야한다!
}
