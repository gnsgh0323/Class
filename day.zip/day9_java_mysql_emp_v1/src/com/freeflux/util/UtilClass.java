package com.freeflux.util;

import java.util.ArrayList;

import com.freeflux.dto.Employee;

public class UtilClass {

	public UtilClass() {
	}

	public static ArrayList<Employee> payRaise(ArrayList<Employee> empList, float n) {
		float raise = n /100;
		System.out.println(raise);
		
		for(Employee employee : empList) {
			float raise1 = employee.getSale() * raise;
			float raise2 = employee.getSale() + raise1;
			employee.setSale((int)raise2);
		}
		return empList;
	}
}
