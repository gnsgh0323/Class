module day9_java_mysql_emp {
	requires java.se;
}