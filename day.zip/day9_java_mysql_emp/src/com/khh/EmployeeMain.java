package com.khh;

import java.util.Scanner;

import com.khh.db.MySQLconnector;

public class EmployeeMain {

	public static void main(String[] args) {
		MySQLconnector mysql = new MySQLconnector();
		mysql.connectMySQL();
		//mysql.selectAll();
		//mysql.selectOne();
		//mysql.insert();
		//mysql.update();
		//mysql.delete();
		
		
		System.out.println();
		Scanner scan = new Scanner(System.in);
		String press = scan.next();
		scan.close();

	}

}
