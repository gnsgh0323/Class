package com.khh.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.khh.employee.Employee;


public class MySQLconnector {
	private String driver = "com.mysql.cj.jdbc.Driver";
	private String url = "jdbc:mysql://localhost:3306/db_emp?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
	private String id_mysql = "root";
	private String pw_mysql = "1234";

	public Connection conn = null;

	public MySQLconnector() {
	}

	public void connectMySQL() {
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, id_mysql, pw_mysql);
			System.out.println("���� ����");
			
		} catch (ClassNotFoundException e) {
			System.out.println("Class.forName(driver) ERR" + e.getMessage());
		} catch (SQLException e) {
			System.out.println("getConnection() ERR" + e.getMessage());
		}
	}
	
	/** ���̺� ������ ��ü ��ȸ 
	 * @return **/
	public ArrayList<Employee> selectAll() {
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<Employee> emps = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery("select * from employee");
			
			emps = new ArrayList<Employee>();
			while (rs.next()) {
				int empNo = rs.getInt("empNo");
				String empName = rs.getString("empName");
				String job = rs.getString("job");
				String mgr = rs.getString("mgr");
				String hireDate = rs.getString("hireDate");
				int sale = rs.getInt("sale");
				int commission = rs.getInt("commission");
				int deptNo = rs.getInt("deptNo");
				
				emps.add(new Employee(empNo, empName, job, mgr, hireDate, sale, commission, deptNo));
			}
		} catch (SQLException e) {
			System.out.println("selectAll() ERR : " + e.getMessage());
		} finally {
			try {
				rs.close();
				stmt.close();
			} catch (SQLException e) {
				System.out.println("Close ERR" + e.getMessage());
			}
		}
		return emps;
	}
	
	/** ���̺� ������ �ϳ��� ��ȸ **/
	public void selectOne() {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "select * from employee where seq_no=?";

		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				System.out.println(rs.getInt("seq_no") + "\t" + rs.getString("empNo") + "\t" + rs.getString("empName")
						+ "\t" + rs.getString("job") + "\t" + rs.getString("mgr") + "\t" + rs.getString("hireDate")
						+ "\t" + rs.getInt("sale") + "\t" + rs.getInt("commission") + "\t" + rs.getInt("deptNo"));
			}
		} catch (SQLException e) {
			System.out.println("selection() ERR" + e.getMessage());
		} finally {
			try {
				rs.close();
				pstmt.close();
			} catch (SQLException e) {
				System.out.println("Close ERR" + e.getMessage());
			}
		}
	}

	public void insert() {
		int id = 0;
		String name = null;
		String query = "insert into employee values(?,?)";
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, id);
			pstmt.setString(2, name);

			int n = pstmt.executeUpdate();
			if (n > 0) {
				System.out.println("����");
			}
		} catch (SQLException e) {
			System.out.println("insert ERR" + e.getMessage());
		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				System.out.println("close ERR" + e.getMessage());
			}
		}
	}

	public void update() {
		int id = 0;
		String name = null;
		String query = "update employee set sale = sale*1.1 where id=?";
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, name);
			pstmt.setInt(2, id);
			int n = pstmt.executeUpdate();
			if (n > 0) {
				System.out.println("����");
			}
		} catch (SQLException e) {
			System.out.println("update ERR:" + e.getMessage());
		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				System.out.println("close ERR:" + e.getMessage());
			}
		}
	}

	public void delete() {
		int id = 0;
		String query = "delete from employee where job='����'";
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, id);
			int n = pstmt.executeUpdate();
			if (n > 0) {
				System.out.println("��������");
			}
		} catch (SQLException e) {
				System.out.println("delete ERR" + e.getMessage());
		}finally {
			try {
				pstmt.close();
			}catch(SQLException e) {
				System.out.println("close ERR" + e.getMessage());
			}
		}
	}
	
	
	
}
