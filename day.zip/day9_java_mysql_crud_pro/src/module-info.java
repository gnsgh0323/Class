module day9_java_mysql {
	requires java.se;  // Java Standard Edition 을 모두 사용
}

// Java Standard Edition : 데스크탑 앱 형태 개발(키오스크)
// Java EE : 자바 웹 개발  
// Java ME : 모바일 앱 개발
