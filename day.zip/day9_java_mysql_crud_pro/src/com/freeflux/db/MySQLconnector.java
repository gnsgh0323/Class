package com.freeflux.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLconnector {
	private String driver = "com.mysql.cj.jdbc.Driver";
	private String url = "jdbc:mysql://localhost:3306/test?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
	private String id_mysql = "root";
	private String pw_mysql ="1234";    // 본인 비밀번호
	
	public Connection conn = null;    // MySQL 접속 결과(상태)를 저장
	
	public MySQLconnector() {
	}
	
	/** MySQL 및 test 데이터베이스 접속 메서드 **/
	/** Connection conn **/
	public void connectMySQL() {
		// 1. driver로드  :  Class.forName("드라이버명")  
		// 2. MySQL과 접속 : DriverManager.getConnection("접속주소", "아이디", "비밀번호")
		// => 외부와 통신하기 때문에 예외처리가 필요.
		
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, id_mysql, pw_mysql);
			System.out.println(" MySQL 접속 성공 !!!");
			
		} catch (ClassNotFoundException e) {
			System.out.println("Class.forName(driver) ERR : " + e.getMessage());
		}catch (SQLException e) {
			System.out.println("getConnection() ERR : " + e.getMessage());
		}

	} //  connectMySQL() END
	
	
	
	
	
	
	/** 테이블 데이터 전체 조회 : select * from member **/
	/** Connection conn / Statement stmt / ResultSet rs **/
	public void selectAll() {   
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery("select * from member");
			
			while(rs.next()) {
				System.out.println(rs.getInt("id")   +  " \t" + rs.getString("name"));
			}

		} catch (SQLException e) {
			System.out.println("전체 레코드 조회 ERR : " + e.getMessage());
			
		}finally {
			try {
				rs.close();
				stmt.close();
			} catch (SQLException e) {
				System.out.println("전체 레코드 조회 CLOSE ERR " + e.getMessage());
			}
		}
		
	} // selectAll() END
	
	/** 테이블 데이터 하나만 조회 : select * from member where id=11 **/
	/** Connection conn / PreparedStatement pstmt / ResultSet rs **/
	public void selectOne() {   
		int idx =11;
		
		PreparedStatement pstmt =null;
		ResultSet rs = null;
		String query = "select * from member where id=?";
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, idx);  // "select * from member where id=11"
			rs = pstmt.executeQuery();    // 사전에 쿼리를 가지고 있기 때문에 실행메서드에는 쿼리 X
			
			while(rs.next()) {
				//System.out.println(rs.getInt("id") + " \t" + rs.getString("name"));
				System.out.println(rs.getInt(1) + " \t" + rs.getString(2));
			}
			
		}catch (SQLException e) {
			System.out.println("레코드 한개 조회 ERR : " + e.getMessage());
		}finally {
			try {
				rs.close();
				pstmt.close();
			}catch (SQLException e) {
				System.out.println("레코드 한개 조회 CLOSE ERR : " + e.getMessage());
			}
		}
		
	} // selectOne() END
	
	
	/** 테이블에  데이터 삽입(추가) : insert into member values (?, ?) **/
	/** Connection conn / PreparedStatement pstmt **/
	public void insert() {     
		int id = 12;
		String name ="자바 MySQL";
		String query = "insert into member values (?, ?)";
		
		PreparedStatement pstmt =null;
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, id);
			pstmt.setString(2, name);
			
			int n = pstmt.executeUpdate();
			if(n > 0) {
				System.out.println("레코드 삽입 성공!!!");
			}
		}catch (SQLException e) {
			System.out.println("레코드 삽입 ERR : " + e.getMessage());
		}finally {
			try {
				pstmt.close();
			}catch (SQLException e) {
				System.out.println("레코드 삽입 CLOSE ERR : " + e.getMessage());
			}
		}
		
	} // insert() END
	
	/** 테이블 데이터 수정 : update member set name=? where id=? **/
	/** Connection conn / PreparedStatement pstmt **/
	public void update() {  
		int id = 10;
		String name ="JDBC";
		String query = "update member set name=? where id=?";
		
		PreparedStatement pstmt =null;
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, name);
			pstmt.setInt(2, id);
			
			
			int n = pstmt.executeUpdate();
			if(n > 0) {
				System.out.println("레코드 수정 성공!!!");
			}
		}catch (SQLException e) {
			System.out.println("레코드 수정 ERR : " + e.getMessage());
		}finally {
			try {
				pstmt.close();
			}catch (SQLException e) {
				System.out.println("레코드 수정 CLOSE ERR : " + e.getMessage());
			}
		}
	} // update() END
	
	/** 테이블 데이터 삭제 : delete from member where id=? **/ 
	/** Connection conn / PreparedStatement pstmt **/
	public void delete() {  
		int id = 2;
		String query = "delete from member where id=?";
		
		PreparedStatement pstmt =null;
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, id);
			
			int n = pstmt.executeUpdate();
			if(n > 0) {
				System.out.println("레코드 삭제 성공!!!");
			}
		}catch (SQLException e) {
			System.out.println("레코드 삭제 ERR : " + e.getMessage());
		}finally {
			try {
				pstmt.close();
			}catch (SQLException e) {
				System.out.println("레코드 삭제 CLOSE ERR : " + e.getMessage());
			}
		}
	} // delete() END
	
} // MySQLconnector class END




