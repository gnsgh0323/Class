package com.freeflux;

import com.freeflux.db.MySQLconnector;
import com.freeflux.db.MySQLconnector2;

public class Main {
	public static void main(String[] args) {
		MySQLconnector mysql = new MySQLconnector();
		mysql.connectMySQL();
//		mysql.selectAll();
//		mysql.selectOne();
		mysql.insert();
		mysql.selectAll();
		mysql.update();
		mysql.selectAll();
		mysql.delete();
		mysql.selectAll();
		
		MySQLconnector2 mysql2 = new MySQLconnector2();
		mysql2.connectMySQL();
//		mysql2.selectAll();
//		mysql2.selectOne();
		
		mysql2.insert();
		mysql2.selectAll();
		
		mysql2.update();
		mysql2.selectAll();
		
		mysql2.delete();
		mysql2.selectAll();
		
		mysql2.close();
	}
}
