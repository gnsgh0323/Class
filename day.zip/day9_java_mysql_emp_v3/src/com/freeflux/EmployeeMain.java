package com.freeflux;

import com.freeflux.util.UtilClass;
import com.freeflux.view.PrintResult;

public class EmployeeMain {

	public static void main(String[] args) {

		PrintResult.printJobSelect();
		UtilClass.ee();

		// */
	} // main() END

}
