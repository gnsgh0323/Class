module day9_java_mysql_crud {
	requires java.se;  // Java Standard Edition 을 모두 사용 -> 자바의 모든 자원을 끌어다 쓰겠다.
					   // Java Standard Edition : 데스크탑 앱 형태 개발(키오스크)
					   // Java EE : 자바 웹 개발
					   // Java ME : 모바일 앱 개발 
}