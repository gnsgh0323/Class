package com.khh;

import com.khh.db.MySQLconnector;

public class Main {

	public static void main(String[] args) {
		MySQLconnector mysql = new MySQLconnector();
		mysql.connectMySQL();
		mysql.selectAll();
		//mysql.selectOne();
		//mysql.insert();
		//mysql.update();
		//mysql.delete();
	}
	
}
