module day8_java_excel {
	requires jxl;     //  requires 라이브러리명  java 11 부터 필수 
}