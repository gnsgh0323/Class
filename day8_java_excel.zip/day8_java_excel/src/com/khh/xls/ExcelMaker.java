package com.khh.xls;

import java.io.File;
import java.io.IOException;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook; // 외부 라이브러리에서 가져온 클래스를 이클리스가 구분해놓음
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

/** 엑셀 파일 생성 및 데이터 추가 **/
public class ExcelMaker {

	public ExcelMaker() {
	}

	public static void excelMaker() {
		String uri = "c:/filetest/data.xls";

		// 1. File 객체가 필요. File 객체의 생성자를 이용하여 파일 경로를 전달
		File f = new File(uri);     // File.class : java.io

		// 2. 쓰기용도의 엑셀 문서(Workbook) 객체 생성 : jxl.jar 파일 안의 클래스
		WritableWorkbook wb = null;

		try {										//              file 객체	
			wb = Workbook.createWorkbook(f);    // 엑셀 문서 틀 만듬
			WritableSheet s  = wb.createSheet("첫번재", 0);     // creatSheet(sheet 이름, sheet에 대한 index 번호);
															
			// 1. 텍스트 : Label.class (를 이용해서 만듬) = new Label(열, 행, 글씨);
			// 2. cell : cell 은 sheet 가 가진 cell 메서드로 만들어준다
			//               => s.addCell(Label)
			
			for(int n = 0; n < 10; n++) {
//                                                         열   행	 내용   		
				Label label = new Label(0,  n, "데이터" + n);   // "데이터0"  jxl
				s.addCell(label);
			}
			
			wb.write();				// 실제로 쓰는 부분
			wb.close();				// 저장하고 종료
			System.out.println("엑셀 파일 생성 완료");
			
		} catch (IOException e) {								// 외부 파일
			System.out.println(e.getMessage());
		} catch (RowsExceededException e) {        // 행에
			System.out.println(e.getMessage());
		} catch (WriteException e) {                          // 쓰기
			System.out.println(e.getMessage());
		}
		
	}   // excelMaker() END
}
