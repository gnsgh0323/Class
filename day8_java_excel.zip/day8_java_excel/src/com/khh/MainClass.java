package com.khh;

import com.khh.xls.ExcelMaker;
import com.khh.xls.ExcelReader;

public class MainClass {

	public static void main(String[] args) {
		//ExcelMaker.excelMaker();
		ExcelReader.excelReader();
	}

}
