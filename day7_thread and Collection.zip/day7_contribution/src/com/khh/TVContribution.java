package com.khh;

/**
 * ARS 모금 ARS는 3개 전화 : 한번 전화 걸 때 마다 자동으로 1,000 씩 모금
 **/
public class TVContribution {
	static Account account;   // -> 모금통
	
	public static void main(String[] args) {
		account = new Account();  // -> 객체 생성은 내부
		
		Customer c1 = new Customer(account, "02-777-0001");
		Customer c2 = new Customer(account, "02-777-0002");
		Customer c3 = new Customer(account, "02-777-0003");
		
		try {						//  start()가 먼저  join()은 뒤에
			
			c1.start();
			c2.start();
			c3.start();
			
			c1.join();
			c2.join();
			c3.join();
			
			
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}
		
			System.out.println("총 모금액 : " + account.getTotal());
	}  // main END

}
