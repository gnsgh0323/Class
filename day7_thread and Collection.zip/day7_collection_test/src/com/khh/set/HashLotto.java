package com.khh.set;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class HashLotto {

	public HashLotto() {
	}

	public static void HashSetLotto() {
		HashSet<Integer> lotto = new HashSet<Integer>();
		//  ㄴ lotto.size() => 0
		
		/** 
		 * 임의의 수 6개를 추출하여 저장
		 * 로또 번호 : 총 45개
		 * '임의의' : 수학 쪽에서 쓰는 Math.random() : 0~1 사이의 실수
		 * 					Random.class 내부에는 정수를 추출해주는 nextInt(범위)
		 * 					nextInt(3) : 0, 1, 2
		 * 					nextInt(45) : 0,~ 45
		 * 
		 * 
		 * Math.random() 를 사용하는 법
		 * 
		 * 		(int)Math.random() * 45 + 1
		 */
		
		Random r = new Random();
		for(int n = 0; lotto.size() < 6; n++) {
//								  ㄴ 현재 로또 사이즈는 0
			int lottoNum = r.nextInt(45);
			lotto.add(new Integer(lottoNum+1));
//										ㄴ 일반 숫자를 Integer 객채로 바꿔서 더해 주어야한다
		}
		
		List<Integer> lottoList = new LinkedList<Integer>(lotto);
		System.out.println(lottoList);   //[16, 33, 21, 8, 12, 31]
		
		Collections.sort(lottoList);        //[8, 12, 16, 21, 31, 33]
		System.out.println(lottoList);   // 사용할 때 주의 해야한다  원본 데이터의 순서가 바뀌어버림
	}
}
