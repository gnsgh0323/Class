package com.khh.set;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetTestClass {

	public HashSetTestClass() {
	}
	
	// 중복 값을 제거해야되다면 set을 사용하자
	public static void hashSetTest() {
		// Set<String> set = new HashSet<String>();   이 방법도 가능
		HashSet<String> set = new HashSet<String>();
		set.add("a");
		set.add("b");
		set.add("c");
		set.add("d");
		
		System.out.println(set.size());
		
		/** 전체 데이터 추출 : Iterator 로 변환 <==== Set.interator() **/
		Iterator<String> iter = set.iterator();
		
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
	}  //  hashSetTest() END
	
}
