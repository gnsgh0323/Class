package com.khh.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class HashMapTestClass {

	public HashMapTestClass() {
	}

	
	/** 기본 데이터 타입
	 *    int					float				boolean		char
	 * 	   Integer        Float               Boolean     Character
	 * 
	 * 	   public class HashMap implements Map{   }
	 **/
	public static void hashMapTest() {  // 여기에는 기본데이터 타입 원형을 써넣어야한다
		Map<String, Integer> map = new HashMap<String, Integer>();
		//HashMap<String, Integer> map2 = new Hashmap<String, Integer>();
		
		/** 데이터 추가 : put(키, 데이터) **/
		map.put("a", 10);
		map.put("a", 20);
		map.put("a", 30);   // ==> 3번을 넣어도 최종 "a" : 30 만 존재  
										   //키=데이터 이기 때문에 하나만 존재한다
		
		map.put("b", 40); 
		map.put("c", 50); 
		map.put("d", 60);   // => 4개 존재
		
		System.out.println(map.size());   // HashMap 의 데이터 갯수
		
		System.out.println("=============");
		
		/** 데이터를 추출하는 방법 : get(Key이름) **/
		System.out.println(map.get("c"));   //  50
		
		System.out.println("=============");
		
		/** HashMap 의 키 이름들만 추출 : keySet() **/
		/**  keySet() 의 반환 타입은 Set<key 에 대한 데이터 타입>**/
		Set<String>set = map.keySet();
		
		// 1. LinkedList 형태로 바꾸어 추출          추가 삭제가 빈번하게 일어날 땐 ArrayList가 빠름  가끔 일어날 땐 LinkedList
		List<String> list = new LinkedList<String>(set); // 생성자에게 set 객체를 전달
		for(String s : list) {
			System.out.println(s);
		}
		
		System.out.println("=============");
		
		// 2. Iterator 형태로 변한하여 출력
		//     Iterator : 열거형 타입     순서없이 나열만 해놓음
		Iterator<String>iter = set.iterator();   // set 은 iterator로 바꿔줄 메서드를 제공
		while(iter.hasNext()) {   //  iter.hasNext()  :   추출할 데이터가 있는지 여부확인 ( true/ false)
			System.out.println(iter.next());    // iter.next() : 데이터를 실제로 추출
		}
	} // HashMapTest END
	
	public static void hashMapStudent() {
		Student s1 = new Student(10, "test1");
		Student s2 = new Student(10, "test2");
		Student s3 = new Student(10, "test3");
		Student s4 = new Student(10, "test4");
		
		Map<String, Student> map = new HashMap<String, Student>();
		map.put("a", s1);
		map.put("b", s2);
		map.put("c", s3);
		map.put("d", s4);
		
		System.out.println(map);
		System.out.println(s1);
		
		// 1. LinkedList 로 출력하는 방법
		// 2. Iterator 로 꺼내는 방법
	} 
	
}
