package com.khh;

import com.khh.list.ArrayListTestClass;
import com.khh.map.HashMapTestClass;
import com.khh.set.HashLotto;
import com.khh.set.HashSetTestClass;

public class MainClass {

	public static void main(String[] args) {
		// ArrayListTestClass.ArrayListTest();
		//HashMapTestClass.hashMapTest();
		//HashMapTestClass.hashMapStudent();
		//HashSetTestClass.hashSetTest();
		HashLotto.HashSetLotto();
	}

}
