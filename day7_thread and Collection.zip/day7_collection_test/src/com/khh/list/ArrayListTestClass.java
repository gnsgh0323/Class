package com.khh.list;

import java.util.ArrayList;

public class ArrayListTestClass {

	public ArrayListTestClass() {
	}

	public static void ArrayListTest() {
		ArrayList<String> list = new ArrayList<String>(); //
		list.add("a"); // ArrayList 에 데이터를 추가
		list.add("b"); // 단, 항상 맨마지막에 추가
		list.add("c"); // 0 : "a" / 1 : "b" / 2 : "c"

		/** 특정 위치를 지정하여 추가할 경우 **/
		// 1번 index에 값을 추가하고싶다?
		list.add(1, "d"); // 1번 인덱스 위치에 "d"를 추가하고, 나머지 데이터는 하나씩 뒤로 밀려난다
		// 0 : "a" / 1 : "d" / 2 : "b" / 3 : "c"

		/** 특정 위치의 데이터를 다른 데이터로 변경 **/
		list.set(2, "f");
		// 0 : "a" / 1 : "d" / 2 : "f" / 3 : "c"

		/** 특정 위치의 데이터를 제거할 경우 **/
		list.remove(0);
		// 0 : "d" / 1 : "f" / 2 : "c"

		/** 특정 위치의 데이터를 제거하고 반환 받을 경우 **/
		String result = list.remove(0);
		//          "d"          0 : "f" / 1 : "c"

		/** 특정 데이터의 index를 알고 싶을 경우 **/
		int idx = list.indexOf("f");
		// 0

		/**
		 * indexOf 주의해야 할 점 예) 0 : "a" / 1 : "b" / 2 : "b" / 3 : "a" / 4 : "c" int idx =
		 * list.indexOf("b"); => 1 -> 앞에서 부터 찾음 0 ===> 4
		 * 
		 * int idx = list.lastIndexOf("b"); => 2 -> 뒤에서 부터 찾음 4 ===> 0
		 * 
		 */

		/** 전체 데이터를 조회하는 방법 (1) for(변수 초기값 ; 조건 ; 증감 ) **/
		for (int ix = 0; ix < list.size(); ix++) {
			System.out.println(list.get(ix));
		}
		
		System.out.println("=================");
		
		/** 전체 데이터를 조회하는 방법 (1) for(내부 데이터 타입 : ArrayList 객체) **/
		for (String s : list) {
			System.out.println(s);
		}

	}
}
