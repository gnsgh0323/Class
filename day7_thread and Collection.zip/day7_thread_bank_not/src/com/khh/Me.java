package com.khh;

public class Me extends Thread {

	public Me() {
	}

	public void run() {
		NotSyncMain.bank.saveMoney(5000);
		System.out.println("입금후 금액 : " + NotSyncMain.bank.getMoney());
	}
}
