package com.khh;

public class NotSyncMain {
	static Bank bank;

	public static void main(String[] agr) {
		bank = new Bank(); // 은행 업무 시작

		System.out.println("현 잔액 : " + bank.getMoney());
		Me m = new Me();
		Wife w = new Wife();
		
		m.start();
		
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}
		
		w.start();
	}
		
}
