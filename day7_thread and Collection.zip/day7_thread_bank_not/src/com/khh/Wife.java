package com.khh;

public class Wife extends Thread{

	public Wife() {
	}
	
	public void run() {
		NotSyncMain.bank.minusMoney(3000);
		System.out.println("출금후 금액 : " + NotSyncMain.bank.getMoney());
	}
}
