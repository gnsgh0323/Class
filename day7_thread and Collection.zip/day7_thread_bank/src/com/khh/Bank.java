package com.khh;

public class Bank {
	private int money = 10000; // 잔액

	public Bank() {
	}

	public int getMoney() {
		return this.money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	// synchronized 다 들어올 떄까지 잠깐 대기시켜줌
	// 입금 처리하는 메서드 (총4개의 메서드중 일하는 메서드)
	public synchronized void saveMoney(int money) {

		try {
			Thread.sleep(3000); // 입금 처리 시간
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}
		this.setMoney(this.money + money); // 현 잔액 + 입금액

		// this.money = this.money + money;

	}

	// 출금 처리하는 메서드 (두 메서드에 synchronized를 붙여준다)
	public void minusMoney(int money) {
		synchronized (this) { // synchronized 를 내부에서 사용하는 방법
			try {
				Thread.sleep(200); // 출금 처리 시간
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}
			this.setMoney(this.money + money);
		}
	}
}
