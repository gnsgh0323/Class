package com.khh;

public class Me extends Thread {

	public Me() {
	}

	public void run() {
		SyncMain.bank.saveMoney(5000);
		System.out.println("입금후 금액 : " + SyncMain.bank.getMoney());
	}
}
