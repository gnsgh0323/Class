package com.khh;

public class SyncMain {
	static Bank bank;

	public static void main(String[] agr) {
		bank = new Bank(); // 은행 업무 시작

		System.out.println("현 잔액 : " + bank.getMoney());
		Me m = new Me();
		Wife w = new Wife();

		// 동기화 하고나면 누가 먼저 시작하던 상관없음
		w.start();

		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}

		m.start();
	}

}
