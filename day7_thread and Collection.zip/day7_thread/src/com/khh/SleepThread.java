package com.khh;

public class SleepThread extends Thread {

	public SleepThread() {
	}

	public void run() {
		 System.out.println("sleep Start !");
		
		 try {
			Thread.sleep(10000);      // => 예외 처리가 필요하니 try-catch문이 필요
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}   
		 
		 
		 System.out.println("sleep End !");
	}
}
