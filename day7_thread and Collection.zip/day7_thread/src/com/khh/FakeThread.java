package com.khh;

public class FakeThread {

	public FakeThread() {

	}

	public void run() {
		// 스레드가 해야할 일들
		int i = 0;
		while (i < 2000) {
			System.out.println("--> " + i); 
			i++;
		}
	}

	public void start() {
		run();
	}

}
