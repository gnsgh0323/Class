package com.khh;

import java.io.File;

public class ThreadTest {

	public static void main(String[] args) {  // 주 스레드(main()) -> 먼저 실행  / start() 메서드가 기본으로 탑재
			System.out.println("main() 시작");
			
			RunnableTest r = new RunnableTest();
			new Thread(r).start();   // -> 이름이 없기 때문에 바로 start 시켜주어야한다 .start
													  //  실행시키면 현재 구동 중인 스레드의 이름 : Thread-0 
			
			System.out.println("main() 종료");

			
	}

}

/**

	(1)	ThreadName t1 = new ThreadName("t1");     // 순차적으로 각 각 실행된다
			ThreadName t2 = new ThreadName("t2");		
			ThreadName t3 = new ThreadName("t3");
			
				t1.start();
				t2.start();
				t3.start();

			try {
				t1.join();
				t2.join();
				t3.join();
			} catch (InterruptedException e) {
					System.out.println(e.getMessage());
			}
			
===========================================

    (2)   implements Runnable Test
    
   			RunnableClass r1 = new RunnableClass();
			RunnableClass r2 = new RunnableClass();
			RunnableClass r3 = new RunnableClass();
			
			new Thread(r1).start();  			// -> 스레드가 start() 메서드를 가지고 있기 때문에 스레드 객체를 만들어주어야한다
			new Thread(r2).start();	  		// 객체 자체에 start() 가 있기 때문에 
		    new Thread(r3).start();			//Thread t1 = new Thread(r1); 를 ->new Thread(r1).start(); 로 쓰면된다
		    
============================================

	(3)   스레드 일정 시간동안 멈추기 : Thread.sleep(1/1000초)
				sleep() 의 시간은 1000 => 1초   (m/sec 단위로 넣어준다)
				sleep() 는 스레드의 진행을 강제적으로 멈추기 때문에 예외처리가 필수이다
				
				SleepThread s = new SleepThread();
			    s.start();
				
============================================

	(4)  implements Runnable 를 이용한 Thread.sleep()
				
*/