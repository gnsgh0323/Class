package com.khh;

												//(1)
public class ThreadName extends Thread {

	public ThreadName() {
	}

	public ThreadName(String name) {
		super(name);
	}

	// (2)
	public void run() {
		// 스레드가 해야할 일들
		int i = 0;
		while (i < 2000) {
			System.out.println(getName()+ "--> " + i);   // getName은 원래 thread것
			i++;
		}
	} // run END
}
