package com.khh;

public class MyThread {
	
	public MyThread() {
	}

}
