package com.khh;

// 어떠한 작업을 3초마다 시킬거임// 런너블을 구현받은 클래스라 이름이 없음  이름을 지으려면
public class RunnableTest implements Runnable {
	int count = 0;
	int num = 0;
	boolean timeout = false;

	public RunnableTest() {
	}

	public RunnableTest(int count) {
		this.count = count;
	}

	@Override
	public void run() {
		while (!timeout) { // timeout => false ! => true
			try {
				Thread.sleep(3000); // 3초 동안 스레드 멈추기
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}

			num++;    // 1
			if (count >= num) {   // 0 <= 1
				timeout = true;     // 이부분이  Thread-0 : 1 찍고 위로 돌아가고  timeout = false 그러고 멈춤

			}
			System.out.println(Thread.currentThread().getName() + " : " + num);

		} // while() END
	} // run() END
}
