package com.khh;

public class RunnableClass implements Runnable {

	@Override // 생략해도 되긴하지만 반드시 명시
	public void run() {
		System.out.println("재정의된 run() 내부");
	}

//	public void start() { 
//		run();
//	}
}
