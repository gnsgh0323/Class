package com.khh;

public class FileMainClass {

	public static void main(String[] args) {
//			FileMethodClass.filewrite("c:/filetest/test.txt");
//			String uri = "C:\\work_java\\day5_file\\src\\com\\khh\\FileMethodClass.java";
//			FileMethodClass.fileread(uri);

		int[] test = { 10, 20, 30, 40, 50 };

		for (int n : test) {
				System.out.println(n);
		}
	}

}
