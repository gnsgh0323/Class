package day5_quiz;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class WordsMethodClass {

	public WordsMethodClass() {
		// TODO Auto-generated constructor stub
	}

	public static int[] searchWords(String uri, ArrayList<String> words) {
		FileReader fr2;
		BufferedReader br2 = null;
		int[] count = new int[words.size()];

		try {
			
			fr2 = new FileReader(uri);
			br2 = new BufferedReader(fr2);
			String temp = "";
			while ((temp = br2.readLine()) != null) {
				String[] split = temp.split(" ");
				for (int w = 0; w < split.length; w++)
					for (int idx = 0; idx < words.size(); idx++) {
						if (split[w].contains(words.get(idx)))
							count[idx]++;
					}
			}
			br2.close();
			fr2.close();

		} catch (FileNotFoundException e) {
				System.out.println(e.getMessage());
		} catch (IOException e) {
				System.out.println(e.getMessage());
		}
		return count;
	}

	public static String createHTML(int[] count, ArrayList<String> words) {
		String tags = "";
		tags = tags + "<html>";
		tags = tags + "<head><title>�ܾ�˻�</title></head>";
		tags = tags + "<body>";
		for (int idx = 0; idx < count.length; idx++) {
			tags = tags + words.get(idx) + ":" + count[idx] + "<br />";
		}
		tags = tags + "</body></html>";
		return tags;
	}
}
