package day5_quiz;

public class WordsMainClass {

	public static void main(String[] args) {
			
			WordsDataClass wdc = new WordsDataClass("C:/filetest/word_list.txt");
			int[] count = WordsMethodClass.searchWords("C:\\filetest\\hadup_file_system.txt",wdc.words);
			String tags =WordsMethodClass.createHTML(count, wdc.words);
			WordsPrintClass.saveHTML("c:/filetest/searchWord.", tags);
			
	}

}
