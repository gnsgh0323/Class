package day5_quiz;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class WordsDataClass {
	ArrayList<String> words = new ArrayList<String>();

	public WordsDataClass() {
	}

	public WordsDataClass(String uri) {
		readWords(uri);
	}

	public void readWords(String uri) {
		FileReader fr = null;
		BufferedReader br = null;

		try {
			fr = new FileReader(uri);
			br = new BufferedReader(fr);

			String temp = "";
			String[] split = null;
			while ((temp = br.readLine()) != null) {
				split = temp.split("\",\"");

				words.add(temp);
			}

			br.close();
			fr.close();

		} catch (FileNotFoundException e) {
			System.out.println("FileNotFoundException => " + e.getMessage());
		} catch (IOException e) {
			System.out.println("IOException => " + e.getMessage());
		}

	}
}
