package day5_quiz;

import java.io.FileWriter;
import java.io.IOException;

public class WordsPrintClass {

	public WordsPrintClass() {
		// TODO Auto-generated constructor stub
	}
	
	public static void saveHTML(String uri, String tags) {
		FileWriter fw = null;
		
		try {
			fw = new FileWriter(uri);
			fw.write(tags);
			fw.close();
		}catch(IOException e) {
			 System.out.println(e.getMessage())
			
		}
	}
	   
	   
	   
	
}
