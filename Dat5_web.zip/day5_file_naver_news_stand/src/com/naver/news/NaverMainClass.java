package com.naver.news;

public class NaverMainClass {

	public static void main(String[] args) {
		// (1)
		String uri = "C:/filetest/naver_news_stand_data_edit.txt";
		NaverDataClass naver = new NaverDataClass(uri);  // (2)
//		System.out.println(naver.news.size());
//		System.out.println(naver.news.get(94).image);
//		System.out.println(naver.news.get(94).url);
		
		// (3)
		String tags = NaverMethodClass.createHTML(naver.news);  // ��ȯ �޾ƾ� �ϴϱ�  tag�� ��ȯ
		System.out.println(tags);
		
		// (4)
		String uri2 = "C:/filetest/naver_news_stand.html"; // ���� ���� �� �� �ʿ�
		NaverPrintClass.saveHTML(uri2, tags);
	}

}
