module day2_class {
}