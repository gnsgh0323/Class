package com.khh;

public class SentenceSplitClass {
	String[] splitSentence = null;

	public SentenceSplitClass() {
		// TODO Auto-generated constructor stub
	}
	public SentenceSplitClass(String[] splitSentence) {
		this.splitSentence = splitSentence;
	}
}
