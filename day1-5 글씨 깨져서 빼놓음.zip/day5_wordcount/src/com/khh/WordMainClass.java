package com.khh;

public class WordMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			String uri_word = "c:/filetest/검색단어리스트.txt";
			String uri_doc = "c:/filetest/하둡 분산 처리 파일 시스템.txt";
			
			WordMethodClass.readWord(uri_word);
			WordMethodClass.readSentence(uri_doc);
			WordMethodClass.SplitSentence();
			
			System.out.println();
	}

}
