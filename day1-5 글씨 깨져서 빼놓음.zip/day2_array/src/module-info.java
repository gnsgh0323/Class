module day2_array {
}