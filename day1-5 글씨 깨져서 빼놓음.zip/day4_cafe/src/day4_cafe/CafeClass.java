package day4_cafe;

public class CafeClass {
		//"order_id", "order_date", "Category", "item", "price"
		String order_id = null;
		String order_date = null;
		String Category = null;
		String item = null;
		int price = 0;
		
	public CafeClass() {
	}
 
	
	
	public CafeClass(String id, String date, String Category, String item, int price) {
		
		this.order_id = id;
		this.order_date = date;
		this.Category  = Category;
		this.item = item;
		this.price = price;
	}
}
