package day4_cafe;

public class CafePrintClass {

	public CafePrintClass() {
	}
	
}
