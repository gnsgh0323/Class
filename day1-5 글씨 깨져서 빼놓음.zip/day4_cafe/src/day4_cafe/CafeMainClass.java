package day4_cafe;

public class CafeMainClass {

	public static void main(String[] args) {
		
			CafeDataClass cdc = new CafeDataClass();
			
			
			
	}

}
