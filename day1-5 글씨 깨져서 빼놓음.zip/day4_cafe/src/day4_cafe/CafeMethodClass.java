package day4_cafe;

import java.util.ArrayList;

public class CafeMethodClass {

	public CafeMethodClass() { // �⺻ ������

	}

	public static ArrayList<String> bestSelling (ArrayList<CafeClass> cafes) {
		ArrayList<String> bestSelling = new ArrayList<String>();
		
		for(int idx = 0; idx < cafes.size(); idx++) {
			
		}
		return bestSelling;
	}

}
