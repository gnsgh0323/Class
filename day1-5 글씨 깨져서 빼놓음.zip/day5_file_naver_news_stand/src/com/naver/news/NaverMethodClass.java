package com.naver.news;

import java.util.ArrayList;

//NaverMethodClass : HTML �±� ����
public class NaverMethodClass {

	public NaverMethodClass() { // �⺻ ������
	}

	public static String createHTML(ArrayList<NaverNewsClass> news) {
		String tags = "";
		tags = tags + "<html>";
		tags = tags + "<head><title>���̹�����</title></head>";
		tags = tags + "<body>";
		tags = tags + "<table border = 1>";

		int idx = 0;
		int rowNum = 7;
		int colNum = 15;
		
		for (int a = 0; a < rowNum; a++) {
			tags = tags + "<tr>";

			for (int b = 0; b < colNum; b++) {
				tags = tags + "<td>";
				tags = tags + "<a href='https://" + news.get(idx).url + "'>";
				tags = tags + "<img src='./newsImages/" + news.get(idx).image + "' />";
				idx++;
				if (idx == news.size()) {
					break;
				}
			}
			tags = tags + "</tr>";
		}
//			for (int n = 0; n < news.size(); n++) { // for - in ������ ����
//				tags = tags + "<td>";
//				tags = tags + "<a href='https://" + news.get(n).url + "'>"; // ' ' ���̿� https://news.get(n).url
//				tags = tags + "<img src='./newsImages/" + news.get(n).image + "' />"; // ' ' ���̿�
//																						// ./newsImages/news.get(n).image
//				tags = tags + "</a>";
//				tags = tags + "</td>";
//			}

//			tags = tags + "</tr>";
			tags = tags + "</table>";
			tags = tags + "</body>";
			tags = tags + "</html>";

			return tags;

		}
	}
