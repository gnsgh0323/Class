package com.khh;

import java.util.ArrayList;

public class NewsMethodClass {

	public NewsMethodClass() { // �⺻ ������
		
	}
	
	//public static String searchNewsURL(ArrayList<NewsClass> news, String press) {
	public static ArrayList<String>searchNewsURL(ArrayList<NewsClass> news, String press) {
		//String url = null;
		ArrayList<String> url = new ArrayList<String>();
		for(int idx =0; idx < news.size(); idx++) {
			
			   // ����       ����        ����Ź�(~~��)
			//if(press.contains(news.get(idx).press))  
		   if(news.get(idx).press.contains(press)) {
			   
				//url = news.get(idx).url; 
			    url.add(news.get(idx).url);
			}
		}
		
		return url;
	} // searchNewsURL() END
	
	public static ArrayList<String>unduplicateCategory (ArrayList<NewsClass>  news) {
		ArrayList<String>unduplicate = new ArrayList<String>();
		  String temp = "";
		  for(int idx = 0; idx < news.size(); idx++) {
			 
			  if(!temp.equals(news.get(idx).category)) {
			  temp = news.get(idx).category;
			  unduplicate.add(temp);
			  }
		  }
		  return unduplicate;
	} // search END
}
